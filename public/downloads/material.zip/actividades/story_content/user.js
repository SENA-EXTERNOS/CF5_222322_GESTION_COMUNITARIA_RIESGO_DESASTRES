function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5gyAJ1TPQK7":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

